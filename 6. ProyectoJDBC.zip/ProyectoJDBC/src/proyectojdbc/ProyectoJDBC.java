/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectojdbc;

/**
 *
 * @author User
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProyectoJDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        // Usuario y contraseña de la base de datos
        String user = "root";
        String password = "";
        String Url = "jdbc:mysql://localhost:3306/bd_proyecto_java";
        // Metodo para conectar a la base de datos
        Connection conexion;
        Statement statement;
        ResultSet rs;

        try {
            Class.forName("com.mysql.cj.jdbc.driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProyectoJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            conexion = DriverManager.getConnection(Url, user, password);
            statement = conexion.createStatement();
            statement.executeUpdate("insert into usuarios (Nombre,Email,Telefono) values ('Eric',"
            + " 'eric@email.com','323456')");
            rs = statement.executeQuery("select * from usuarios");
            rs.next();
            do {                
                System.out.println(rs.getInt("ID")+ " - "+rs.getString("Nombre")
                + " - "+rs.getString("Email"));
            } while (rs.next());
                
        } catch (SQLException ex) {
            Logger.getLogger(ProyectoJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }

}
